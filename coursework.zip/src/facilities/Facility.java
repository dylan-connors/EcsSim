package facilities;

public class Facility {
    String name;

    public Facility(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
